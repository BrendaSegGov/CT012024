package ejemploJava;

public class DemoEncap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EncapClase ec = new EncapClase();
		ec.setTipo(5);
		
		System.out.println("El tipo es: " + ec.getTipo());
	}

}
