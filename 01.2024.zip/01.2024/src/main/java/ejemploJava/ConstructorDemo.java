package ejemploJava;

public class ConstructorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MiClase t1 = new MiClase();
		
		System.out.println(t1.x);
		
		MiClase t2 = new MiClase();
		
		System.out.println(t2.x);
	}

}
