package ejemploJava;

public class DosDimensiones {
	
	double base;
	double altura;
	
	void mostrarDimension() {
		System.out.println("La base y altura es: " + base + " y " + altura);
	}
}
