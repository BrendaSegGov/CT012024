package ejemploJava;

public class Vehiculo {

	int pasajeros;
	int capacidad;
	int kmh;
	
}
