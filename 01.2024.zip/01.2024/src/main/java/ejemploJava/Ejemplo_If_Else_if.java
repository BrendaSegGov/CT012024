package ejemploJava;

public class Ejemplo_If_Else_if {

	public static void main(String[] args) {
		
		int i =20;
		
		if(i==10) {
			System.out.println("i es 10");
		}
		else if (i == 15) {
			System.out.println("i es 15");
		}
		else if (i == 20) {
			System.out.println("i es 20");
		}
		else {
			System.out.println("I no equivale a ninguna de las condiciones");
		}

	}

}
