package ejemploJava;

public class EncapClase {
	
	private int tipo;
	
	public void setTipo (int t) {
		tipo = t;
	}
	public int getTipo() {
		return tipo;
	}
}
