package ejemploJava;

public class Ejemplo_If {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=9;
		
		if(i<15) {
			System.out.println("10 es menor que 15");
			}
		System.out.println("No estoy en If");
	}

}
