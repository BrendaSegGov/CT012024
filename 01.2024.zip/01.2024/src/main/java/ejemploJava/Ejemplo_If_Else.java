package ejemploJava;

public class Ejemplo_If_Else {

	public static void main(String[] args) {
		int i = 10;
		if (i < 15) {
			System.out.println("Soy menor que 15");
		}
		else {
	System.out.println("Soy mayor que 15");
		}
	}
}
