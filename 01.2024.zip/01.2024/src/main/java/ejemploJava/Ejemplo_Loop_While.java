package ejemploJava;

public class Ejemplo_Loop_While {

	public static void main(String[] args) {
		int a =1;
		
		while (a <= 4) {
			System.out.println("el valor de A: " + a);
			a++;
		}

	}
}
