package ejemploJava;

public class Ejemplo_Loop_Dowhile {

	public static void main(String[] args) {
		
		int b = 10;
		do {
			System.out.println("El valor de B es: " + b);
			b++;
		}
		while (b <= 20);
	}

}
