package ejemploJava;

public class MiClase {

	int x;
	MiClase(){
		x= 10;
	}
	
}
