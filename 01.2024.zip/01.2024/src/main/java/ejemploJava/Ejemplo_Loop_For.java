package ejemploJava;

public class Ejemplo_Loop_For {

	public static void main(String[] args) {
		
		int y = 5;
		
		for (int x = 0; x <= y; x++) {
			System.out.println("El valor de x: " + x);
		}

	}

}
